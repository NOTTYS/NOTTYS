import React from 'react'

function Sidebar() {
  return (
    <div>
        <h1>Sidebar</h1>
    </div>
  )
}

export default Sidebar