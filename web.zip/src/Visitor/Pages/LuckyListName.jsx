import React from 'react'
import 'react-bootstrap'
import '../Assets/sass/renderPageNumbers.scss'
import LuckyPeople from '../Components/LuckyPeople';

function LuckyListName() {

  return (
    <div>
        <LuckyPeople/>
    </div>
  )
}

export default LuckyListName