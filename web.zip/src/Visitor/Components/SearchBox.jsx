import React from 'react'

function SearchBox() {
  return (
    <div>SearchBox</div>
  )
}

export default SearchBox