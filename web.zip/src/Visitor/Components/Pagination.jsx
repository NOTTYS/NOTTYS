import React from 'react'
import LuckyGuys from '../../JSON/LuckyGuys.json'
import {useState} from 'react'

function Pagination() {
    // const [people, setPeople] = useState(LuckyGuys.slice(0, 50))
    // const [pageNumber, setPageNumber] = useState(1)
    
    // const itemsPerPage = 5
    // const pageVisited = pageNumber * itemsPerPage
    // const displayUsers =  people.slice(pageVisited, pageVisited + itemsPerPage).map(people => {

    // })
    // console.log(itemsPerPage)
  return (
    <div>
        
    </div>
  )
}

export default Pagination