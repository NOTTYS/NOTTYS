import React from 'react'


function FormPopUp(props) {
 
  return (
    <div>
       
    </div>
  )
}

export default FormPopUp