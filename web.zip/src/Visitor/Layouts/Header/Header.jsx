import React from 'react'
import Navbarr from '../../Components/Navbar'

function Header() {
  return (
    <div>
      <header>
        <Navbarr/>
        </header>
    </div>
  )
}

export default Header